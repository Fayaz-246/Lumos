module.exports = {
  // Embed Colors

  embedColor: "#000100",
  successColor: "Green",
  errorColor: "Red",

  emojis: {
    ticket: "🎫",
    success: "<:Mod_Check:1175049375383293962>",
    error: "<:Mod_Error:1175049241320751215>",
  },
};
